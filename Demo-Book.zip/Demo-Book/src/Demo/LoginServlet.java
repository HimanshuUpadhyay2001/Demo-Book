package Demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login-servlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	
		// read form user input
		String username1=request.getParameter("Username");
		String password=request.getParameter("Password");
	
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("driver loaded");
		}catch(Exception e) {
			e.printStackTrace();
		}
		//create connection
		String url="jdbc:mysql://localhost:3306/newproject";
		String username="root";
		String userpassword="2001";
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/newproject","root","2001");
			System.out.println("connection established");
			//query
		
		PreparedStatement pstmt=con.prepareStatement("Select * from project where username1=? and password=?");
		
		pstmt.setString(1, username1);
		pstmt.setString(2, password);
		
		ResultSet rs=pstmt.executeQuery();
		
		while(rs.next()) {
			int id=rs.getInt("id");
			String username2=rs.getString("username1");
			String password2=rs.getString("password");
		
			
			response.sendRedirect("home.jsp");
		
		}
		
		}catch(Exception e) {
			e.printStackTrace();
			
		response.sendRedirect("Login.jsp");
		
		}
		}}	
		
		
		
		
		
		
		
		
		
		